﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Star_csharp;

namespace windows_csharp_call_ruby_kramdown
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            StarCoreFactory starcore = StarCoreFactory.GetFactory();
            starcore._RegMsgCallBack_P((int ServiceGroupID, int uMes, Object wParam, Object lParam) => 
            {
                if (uMes == starcore._Getint("MSG_DISPMSG") || uMes == starcore._Getint("MSG_DISPLUAMSG") || uMes == starcore._Getint("MSG_VSDISPMSG") || uMes == starcore._Getint("MSG_VSDISPLUAMSG"))
                {
                    Debug.WriteLine((String)wParam);
                }
                return null;
            });
            StarServiceClass Service = starcore._InitSimple("test", "123", 0, 0, null);
            StarSrvGroupClass SrvGroup = (StarSrvGroupClass)Service._Get("_ServiceGroup");
            Service._CheckPassword(false);

            SrvGroup._InitRaw("ruby", Service);
            dynamic varruby = Service._ImportRawContext("ruby", "", false, "");

            dynamic LOAD_PATH = varruby.LOAD_PATH;
            LOAD_PATH.unshift("C:\\Ruby22\\lib\\ruby\\gems\\2.2.0\\gems\\kramdown-1.16.2\\lib");

            /*--load kramdown-- */
            varruby.require("kramdown");
            dynamic KramdownDocument= varruby.eval("Kramdown::Document");
            dynamic resobj = KramdownDocument._New("","","# aaaaaa");

            dynamic Result  = resobj.method_missing("to_html");
            string str = Result as string;
        }
    }
}
