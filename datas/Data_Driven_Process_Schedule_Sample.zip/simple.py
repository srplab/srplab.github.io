import pchain
from pchain import pydata
from pchain import pyproc

Service = pchain.cleinit()
import libstarpy

realm = Service.PCRealmBase()

# Define data types
pydata.DefineType('NumberClass')

d = NumberClass(12.3)
key = d.GetTag()
print(key)

buf=Service._ServiceGroup._NewParaPkg()
realm.SaveObject(buf,d)
val = buf._ToJSon()
print(val)

l_buf=Service._ServiceGroup._NewParaPkg()
l_buf._FromJSon(val)
l_d = realm.LoadObject(l_buf,True)
print(l_d[0])

@pyproc.DefineProc('HelloWorldProc',None,None)
def Execute(self) :  
  print('Hello world !')
  return (0,1,None)

cle_p = HelloWorldProc().Wrap()
key = cle_p.GetTag()
print(key)

buf=Service._ServiceGroup._NewParaPkg()
realm.SaveObject(buf,cle_p)
val = buf._ToJSon()
print(val)

# Define procedure types
@pyproc.DefineProc('InputProc',None,NumberClass)
def Execute(self) :  
  Context = self.Context  #  first must save Context in local variable
  if Context['SelfObj'].Status < 0 :
    return None
  val = input('input a number : ')
  return (4,1,NumberClass(val))

# Define procedure types
@pyproc.DefineProc('OutputProc',(NumberClass,NumberClass),None)
def Execute(self,num1,num2) :  
  Context = self.Context  #  first must save Context in local variable
  print('sum = ', num1.value() + num2.value())
  Context['Cell'].Finish()
  return (0,1,None)
  
cell = Service.PCCellBase()
cell.AddProc(InputProc,OutputProc)

realm.AddCell(cell)
realm.Execute()
  
# enter loop
# pchain.cleloop()
# finish
pchain.cleterm() 