import com.srplab.www.starcore.*;

public class java_call_ruby_kramdown{
	public static void main(String[] args){

        final StarCoreFactory starcore= StarCoreFactory.GetFactory();
        StarServiceClass Service=starcore._InitSimple("test","123",0,0);
        StarSrvGroupClass SrvGroup = (StarSrvGroupClass)Service._Get("_ServiceGroup");
        Service._CheckPassword(false);

        starcore._RegMsgCallBack_P(new StarMsgCallBackInterface(){
            public Object Invoke(int ServiceGroupID, int uMes, Object wParam, Object lParam){
                if (uMes == starcore._Getint("MSG_DISPMSG") || uMes == starcore._Getint("MSG_DISPLUAMSG") ||
                        uMes == starcore._Getint("MSG_VSDISPMSG") || uMes == starcore._Getint("MSG_VSDISPLUAMSG"))
                {
                    String Str;
                    Str = (String)wParam;
                    System.out.println(Str);
                }
                return null;
            }
        });

        starcore._SetScript("ruby","", "-v 2.2.0");
        SrvGroup._InitRaw("ruby",Service);
        StarObjectClass ruby = Service._ImportRawContext("ruby","",false,"");

        StarObjectClass LOAD_PATH = (StarObjectClass)ruby._R("LOAD_PATH");
        LOAD_PATH._Call("unshift", "C:\\Ruby22\\lib\\ruby\\gems\\2.2.0\\gems\\kramdown-1.16.2\\lib");
        
        ruby._Call("require","kramdown");
        StarObjectClass KramdownDocument = (StarObjectClass)ruby._Call("eval","Kramdown::Document");
        StarObjectClass resobj = KramdownDocument._New("","","# aaaaaa");
        Object res = resobj._Call("method_missing","to_html");        
        System.out.println(res);
                
   	    SrvGroup._ClearService();
        starcore._ModuleExit();
    }
}    
