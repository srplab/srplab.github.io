﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

using Star_csharp;
using Libstarcore;
using System.Diagnostics;
using Windows.Storage;
using System.IO.Compression;
using Windows.ApplicationModel;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace uwp_csharp_call_ruby_kramdown
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();

            StarCoreFactoryInit.Init(this);

            StarCoreFactory starcore = StarCoreFactory.GetFactory();
            StarServiceClass Service = (StarServiceClass)starcore._InitSimple("test", "123", 0, 0, null);
            StarSrvGroupClass SrvGroup = (StarSrvGroupClass)Service._Get("_ServiceGroup");
            starcore._RegMsgCallBack_P(new StarMsgCallBackInterface(delegate (int ServiceGroupID, int uMes, object wParam, object lParam) {
                if (uMes == starcore._Getint("MSG_VSDISPMSG") || uMes == starcore._Getint("MSG_VSDISPLUAMSG") || uMes == starcore._Getint("MSG_DISPMSG") || uMes == starcore._Getint("MSG_DISPLUAMSG"))
                {
                    Debug.WriteLine((string)wParam);
                }
                return null;
            }));

            //---unzip ruby.zip and kramdown.zip to app folder
            //---Package.Current.InstalledLocation;
            //---ApplicationData.Current.LocalFolder;
            try
            {
                ZipFile.ExtractToDirectory(Package.Current.InstalledLocation.Path + "\\ruby.zip", ApplicationData.Current.LocalFolder.Path);
            }
            catch(Exception)
            {

            }
            try
            {
                ZipFile.ExtractToDirectory(Package.Current.InstalledLocation.Path + "\\kramdown-1.16.2.zip", ApplicationData.Current.LocalFolder.Path);
            }
            catch(Exception)
            {

            }
            //---
            bool InitRawFlag = SrvGroup._InitRaw("ruby", Service);
            dynamic ruby = Service._ImportRawContext("ruby", "", false, "");

            //---set module path
            dynamic LOAD_PATH = ruby.LOAD_PATH;
            LOAD_PATH.unshift(Package.Current.InstalledLocation.Path);
            LOAD_PATH.unshift(ApplicationData.Current.LocalFolder.Path+ "\\ruby\\2.2.0");
            LOAD_PATH.unshift(ApplicationData.Current.LocalFolder.Path + "\\kramdown-1.16.2\\lib");

            ruby.require("kramdown");
            dynamic KramdownDocument = ruby.eval("Kramdown::Document");
            dynamic resobj = KramdownDocument._New("", "", "# aaaaaa");
            string res = resobj.method_missing("to_html");
            res = null;
        }
    }
}
