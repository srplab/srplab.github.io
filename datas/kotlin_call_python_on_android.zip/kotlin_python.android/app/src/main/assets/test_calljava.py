import os
import json

print(JavaClass)

val = JavaClass("from python")
val.SetPythonObject(json);
print("===========end=========")