package com.srplab.www.kotlin_python

import com.srplab.www.starcore.StarObjectClass
import com.srplab.www.starcore.StarParaPkgClass

class CallBackClass(Info: String) {
    init {
        println(Info)
    }

    fun SetPythonObject(rb: Any) {
        val PythonClass = rb as StarObjectClass
        val aa = ""
        val data1 = MainActivity.Host.SrvGroup._NewParaPkg("b", 789, "c", 456, "a", 123)._AsDict(true)
        val d1 = PythonClass._Call("dumps", data1, MainActivity.Host.SrvGroup._NewParaPkg("sort_keys", true)._AsDict(true))
        println("" + d1)
        val d2 = PythonClass._Call("dumps", data1)
        println("" + d2)
        val d3 = PythonClass._Call("dumps", data1, MainActivity.Host.SrvGroup._NewParaPkg("sort_keys", true, "indent", 4)._AsDict(true))
        println("" + d3)
    }
}
