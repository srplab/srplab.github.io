package com.srplab.www.kotlin_python

import android.app.Activity
import android.support.v7.app.AppCompatActivity
import android.os.Bundle

import com.srplab.www.starcore.StarCoreFactory
import com.srplab.www.starcore.StarCoreFactoryPath
import com.srplab.www.starcore.StarObjectClass
import com.srplab.www.starcore.StarSrvGroupClass
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream


class MainActivity : AppCompatActivity() {

    lateinit var SrvGroup: StarSrvGroupClass
    companion object {
        lateinit var Host: MainActivity
    }

    @Throws(IOException::class)
    private fun copyFile(c: Activity, Name: String, desPath: String?) {
        var outfile: File? = null
        outfile = File("/data/data/$packageName/files/$Name")
        outfile.createNewFile()
        val out = FileOutputStream(outfile)
        val buffer = ByteArray(1024)
        val f_in: InputStream
        var readLen = 0
        if (desPath != null)
            f_in = c.assets.open(desPath + Name)
        else
            f_in = c.assets.open(Name)
        readLen = f_in.read(buffer)
        while (readLen != -1) {
            out.write(buffer, 0, readLen)
            readLen = f_in.read(buffer)
        }
        out.flush()
        f_in.close()
        out.close()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Host = this

        val destDir = File("/data/data/$packageName/files")
        if (!destDir.exists())
            destDir.mkdirs()
        val python2_7_libFile = java.io.File("/data/data/$packageName/files/python3.6.zip")
        if (!python2_7_libFile.exists()) {
            try {
                copyFile(this, "python3.6.zip", null)
            } catch (e: Exception) {
            }

        }
        try {
            val nativeLibraryDir = this.getApplicationInfo().nativeLibraryDir
            if (nativeLibraryDir.contains("x86")) {
                copyFile(this, "_datetime.cpython-36m.so", "x86/")
                copyFile(this, "_socket.cpython-36m.so", "x86/")
                copyFile(this, "_struct.cpython-36m.so", "x86/")
                copyFile(this, "array.cpython-36m.so", "x86/")
                copyFile(this, "binascii.cpython-36m.so", "x86/")
                copyFile(this, "select.cpython-36m.so", "x86/")
                copyFile(this, "unicodedata.cpython-36m.so", "x86/")
                copyFile(this, "zlib.cpython-36m.so", "x86/")
            } else {
                copyFile(this, "_datetime.cpython-36m.so", "armeabi/")
                copyFile(this, "_socket.cpython-36m.so", "armeabi/")
                copyFile(this, "_struct.cpython-36m.so", "armeabi/")
                copyFile(this, "array.cpython-36m.so", "armeabi/")
                copyFile(this, "binascii.cpython-36m.so", "armeabi/")
                copyFile(this, "select.cpython-36m.so", "armeabi/")
                copyFile(this, "unicodedata.cpython-36m.so", "armeabi/")
                copyFile(this, "zlib.cpython-36m.so", "armeabi/")
            }
            copyFile(this, "test_calljava.py", "")
            copyFile(this, "testpy.py", "")
        } catch (e: Exception) {
            println(e)
        }

        val libpath = this.applicationInfo.nativeLibraryDir
        try {
            //--load python36 core library first;
            System.load(libpath + "/libpython3.6m.so")
        } catch (ex: UnsatisfiedLinkError) {
            println(ex.toString())
        }

        /*----init starcore----*/
        StarCoreFactoryPath.StarCoreCoreLibraryPath = libpath //"/data/data/"+getPackageName()+"/lib";
        StarCoreFactoryPath.StarCoreShareLibraryPath = libpath //"/data/data/"+getPackageName()+"/lib";
        StarCoreFactoryPath.StarCoreOperationPath = "/data/data/$packageName/files"

        val starcore = StarCoreFactory.GetFactory()
        val Service = starcore._InitSimple("test", "123", 0, 0)
        SrvGroup = Service._Get("_ServiceGroup") as StarSrvGroupClass
        Service._CheckPassword(false)

        /*----run python code----*/
        SrvGroup._InitRaw("python36", Service)
        val python = Service._ImportRawContext("python", "", false, "")
        SrvGroup._RunScript("python", "import sys", "")

        python._Call("import", "sys")

        val pythonSys = python._GetObject("sys")
        val pythonPath = pythonSys._Get("path") as StarObjectClass
        pythonPath._Call("insert", 0, "/data/data/$packageName/files/python3.6.zip")
        pythonPath._Call("insert", 0, "/data/data/$packageName/lib")
        pythonPath._Call("insert", 0, "/data/data/$packageName/files")

        val CorePath = "/data/data/$packageName/files"
        Service._DoFile("python", CorePath + "/testpy.py", "")

        println(python._Get("g1"));
        val retobj = python._Call("tt", "hello ", "world") as StarObjectClass
        println(" "+retobj._Get(0)+" "+retobj._Get(1)+" "+retobj._Get(2))

        python._Set("JavaClass", CallBackClass::class.java)
        Service._DoFile("python", CorePath + "/test_calljava.py", "")

    }
}
