Service=libstarcore._InitSimple("test","123",0,0,nil);
SrvGroup = Service._ServiceGroup;
Service:_CheckPassword(false)

result = Service:_DoFile("","./testgo.dll","");
print(result);

LuaObj = Service:_New("LuaObj")
Python = Service.testgo
print(Python)

function LuaObj:Print()
    print("hello from lua")
    print(Python)
    libstarcore._SRPUnLock()
    libstarcore._SRPLock()    
end    

Python:tt(222,333)

function aa()
  -- libstarcore._SRPUnLock()
  i = 0
  j = 0
  while( true ) do
      libstarcore._SRPDispatch(true)
      if i == 10 then
          print("----------------------------------------")
          Python:tt1("123",j);
          j = j + 1
          i = 0
      end
      i = i + 1
  end  
end

aa()


libstarcore._SRPUnLock()

while( true ) do
  
end


SrvGroup:_ClearService()
libstarcore._ModuleExit()