// main
package main

import (
	"fmt"
	"time"

	"github.com/srplab/starcore_for_go/stargo"
)

func main() {
	fmt.Println("Hello World!")
}

func print_time(LuaObj *stargo.StarObject, threadName string, delay float64) {
	var count int
	count = 0
	stargo.Println(threadName)
	stargo.Println(delay)
	for {
		if count > 100000 {
			break
		}
		time.Sleep(time.Duration(delay) * time.Second)
		stargo.Println(threadName)
		stargo.Println(delay)
		count = count + 1
		stargo.SRPLock()
		stargo.Println(LuaObj)
		LuaObj.Call("Print")
		stargo.SRPUnLock()
	}
}

func init() {
	stargo.RegScriptTermCallBack_P(func() {
		stargo.Println("go script engine exit...")
	})

	stargo.RegScriptInitCallBack_P(func(SrvGroup *stargo.StarSrvGroup, Service *stargo.StarService) {
		stargo.Println("go script engine init...")

		/*--testgo can be called from other script */
		s := Service.New("testgo")
		s.RegScriptProc_P("tt", func(CleGroup *stargo.StarSrvGroup, CleService *stargo.StarService, CleObject *stargo.StarObject, Paras []interface{}) interface{} {
			stargo.Println(Paras)
			LuaObj := CleService.GetObject("LuaObj")
			stargo.Println(LuaObj)
			go print_time(LuaObj, "Thread-1", 1.0)
			go print_time(LuaObj, "Thread-2", 2.0)

			return []interface{}{666, 777}
		})
		s.RegScriptProc_P("tt1", func(CleGroup *stargo.StarSrvGroup, CleService *stargo.StarService, CleObject *stargo.StarObject, Paras []interface{}) interface{} {
			stargo.Println(Paras)
			return []interface{}{666, 777}
		})
	})
}
