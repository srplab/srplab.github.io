go build -buildmode=c-shared -o testgo.dll

"C:\Program Files\srplab\starcore\starapp" --print -e call_go.lua