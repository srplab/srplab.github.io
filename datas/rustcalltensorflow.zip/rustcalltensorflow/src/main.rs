#![allow(unused_variables)]
#![allow(non_snake_case)]
#![allow(unused_imports)]

#[macro_use] extern crate starcore_for_rust;
use starcore_for_rust::*;
use std::any::Any;
use std::collections::HashMap;

fn MsgCallBack(ServiceGroupID: u32, uMsg: u32, wParam: &Any, lParam: &Any) -> (bool, Box<Any>)
{
	if uMsg == MSG_VSDISPMSG || uMsg == MSG_VSDISPLUAMSG || uMsg == MSG_DISPMSG || uMsg == MSG_DISPLUAMSG {
		println!("{}",starrust::ToString(wParam));
	} else {
	}
	return (false, Box::new(&0));
}

fn main() {
	let Service = starrust::InitSimple(&"test",&"123", 0, 0,&[]);
    starrust::RegMsgCallBack_P(MsgCallBack);
	let SrvGroup = Service.Get(&"_ServiceGroup").ToSrvGroup();
    Service.CheckPassword(false);

    let initResult = SrvGroup.InitRaw(&"python", &Service);
    let python = Service.ImportRawContext(&"python", &"", false, &"");

	star_call!(python,"import","tensorflow");
	let tf = python.GetObject(&"tensorflow");    

	let a = star_callobject!(tf,"constant",5,star_dict!(SrvGroup,"name"=>"input_a")); 
	let b = star_callobject!(tf,"constant",3,star_dict!(SrvGroup,"name"=>"input_b"));

	let c = star_callobject!(tf,"multiply",a, b,star_dict!(SrvGroup,"name"=>"mul_c"));  
	let d = star_callobject!(tf,"add", a, b,star_dict!(SrvGroup,"name"=>"add_d"));

	let e = star_callobject!(tf,"add",c, d, star_dict!(SrvGroup,"name"=>"add_e_d"));

	let sess = star_callobject!(tf,"Session",);
	let r = star_callobject!(sess,"run", e);

	println!("{}",r.ToString());
}
