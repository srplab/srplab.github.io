// test project main.go
package main

import (
	"fmt"
	"github.com/srplab/starcore_for_go/stargo"
)

func main() {
	Service := stargo.InitSimple("test", "123", 0, 0)
	SrvGroup := Service.Get("_ServiceGroup").(*stargo.StarSrvGroup)
	Service.CheckPassword(false)

	result := Service.DoFile("",SrvGroup.GetCurrentPath() + "/target/debug/rustsharelib.dll","")
	fmt.Println(result);
	fmt.Println(Service.GetObject("RustObject"));
	fmt.Println(Service.GetObject("RustObject").Call("PrintHello","------------1",234.56));

	SrvGroup.ClearService();
	stargo.ModuleExit();
}
