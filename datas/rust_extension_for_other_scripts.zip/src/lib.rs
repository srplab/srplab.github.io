#![allow(non_snake_case)]
#![allow(unused_variables)]

#[macro_use] extern crate starcore_for_rust;
use starcore_for_rust::*;
use std::os::raw::{c_void};

star_extension!(SrvGroup,Service {
    /*--create a new cle object, other script can find the object by it's name--*/
	let obj = Service.New(&[&"RustObject"]);
    /*--define function "PrintHello" of cle object--*/
    star_fn!(obj,"PrintHello",CleGroup,CleService,CleObject,a:String, b:f64 {
        println!("########{:?}",a);
        println!("########{:?}",b);
        star_ret!(star_parapkg!(CleGroup,"return from go",345.4));
    });     
});