import com.srplab.www.starcore.*;

public class call_rust{ 
	public static void main(String[] args){
		StarCoreFactory starcore= StarCoreFactory.GetFactory();
		StarServiceClass Service=starcore._InitSimple("test","123",0,0);
		StarSrvGroupClass SrvGroup = (StarSrvGroupClass)Service._Get("_ServiceGroup");
		Service._CheckPassword(false);

    Object result = Service._DoFile("",SrvGroup._GetCurrentPath() + "/target/debug/rustsharelib.dll","");
    System.out.println(result);
    System.out.println(Service._GetObject("RustObject"));
    System.out.println(Service._GetObject("RustObject")._Call("PrintHello","------------1",234.56));
		
		SrvGroup._ClearService();
		starcore._ModuleExit();
    }
}		

/*
javac -classpath .;c:\srplab\libs64\starcore.jar call_rust.java
java -classpath .;c:\srplab\libs64\starcore.jar call_rust
[Ljava.lang.Object;@1b28cdfa
RustObject
########"------------1"
########234.56
parapkg
*/