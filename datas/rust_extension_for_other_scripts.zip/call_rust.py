import libstarpy
Service=libstarpy._InitSimple("test","123",0,0);
SrvGroup = Service._ServiceGroup;
Service._CheckPassword(False)

result = Service._DoFile("","./target/debug/rustsharelib.dll","");
print(result)
print(Service.RustObject)
print(Service.RustObject.PrintHello("------------1",234.56))

SrvGroup._ClearService()
libstarpy._ModuleExit()
