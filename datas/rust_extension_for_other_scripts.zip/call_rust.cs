using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Star_csharp;

namespace call_rust
{
    class Program
    {
        static void Main(string[] args)
        {
					StarCoreFactory starcore= StarCoreFactory.GetFactory();
					StarServiceClass Service=starcore._InitSimple("test","123",0,0);
					StarSrvGroupClass SrvGroup = (StarSrvGroupClass)Service._Get("_ServiceGroup");
					Service._CheckPassword(false);

			    object result = Service._DoFile("",SrvGroup._GetCurrentPath() + "/target/debug/rustsharelib.dll","");
			    Console.WriteLine(result);
			    Console.WriteLine(Service._GetObject("RustObject"));
			    Console.WriteLine(Service._GetObject("RustObject")._Call("PrintHello","------------1",234.56));
		
					SrvGroup._ClearService();
					starcore._ModuleExit();
		    }
		}
}		

/*
csc /reference:c:\srplab\libs64\star_csharp462.dll /platform:x64 call_rust.cs
*/