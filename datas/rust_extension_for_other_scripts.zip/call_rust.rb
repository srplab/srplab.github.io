if (defined? Libstar_ruby) == nil
   require "C:\\srplab\\libs64\\libstar_ruby.so"
end  
$Service=$starruby._InitSimple("test","123",0,0,nil);
$SrvGroup = $Service._ServiceGroup;
$Service._CheckPassword(false)

result = $Service._DoFile("",$SrvGroup._GetCurrentPath() + "/target/debug/rustsharelib.dll","");
puts(result)
puts($Service.RustObject)
puts($Service.RustObject.PrintHello("------------1",234.56))
$SrvGroup._ClearService()
$starruby._ModuleExit()

#[warn(1):(ruby:32745):tm(11:40:26)]can not load ruby core share library[C:\Ruby25-x64\bin\x64-msvcrt-ruby250.dll][error code = 126
#add path for environment
#C:\Ruby25-x64\bin\ruby_builtin_dlls