package com.example.srplab.test_aiohttp;

import android.app.Activity;
import android.content.res.AssetManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import com.srplab.www.starcore.*;

public class MainActivity extends AppCompatActivity {

    private void copyFile(Activity c, String Name, String desPath) throws IOException {
        File outfile = null;
        //if( desPath != null )
        //    outfile = new File("/data/data/"+getPackageName()+"/files/"+desPath+Name);
        //else
        outfile = new File("/data/data/"+getPackageName()+"/files/"+Name);
        //if (!outfile.exists()) {
        {
            outfile.createNewFile();
            FileOutputStream out = new FileOutputStream(outfile);
            byte[] buffer = new byte[1024];
            InputStream in;
            int readLen = 0;
            if (desPath != null)
                in = c.getAssets().open(desPath + Name);
            else
                in = c.getAssets().open(Name);
            while ((readLen = in.read(buffer)) != -1) {
                out.write(buffer, 0, readLen);
            }
            out.flush();
            in.close();
            out.close();
        }
    }

    private static boolean CreatePath(String Path){
        File destCardDir = new File(Path);
        if(!destCardDir.exists()){
            int Index = Path.lastIndexOf(File.separator.charAt(0));
            if( Index < 0 ){
                if( destCardDir.mkdirs() == false )
                    return false;
            }else{
                String ParentPath = Path.substring(0, Index);
                if( CreatePath(ParentPath) == false )
                    return false;
                if( destCardDir.mkdirs() == false )
                    return false;
            }
        }
        return true;
    }

    private static boolean unzip(InputStream zipFileName, String outputDirectory,Boolean OverWriteFlag ) {
        try {
            ZipInputStream in = new ZipInputStream(zipFileName);
            ZipEntry entry = in.getNextEntry();
            byte[] buffer = new byte[1024];
            while (entry != null) {
                File file = new File(outputDirectory);
                file.mkdir();
                if (entry.isDirectory()) {
                    String name = entry.getName();
                    name = name.substring(0, name.length() - 1);
                    if( CreatePath(outputDirectory + File.separator + name) == false )
                        return false;
                } else {
                    String name = outputDirectory + File.separator + entry.getName();
                    int Index = name.lastIndexOf(File.separator.charAt(0));
                    if( Index < 0 ){
                        file = new File(outputDirectory + File.separator + entry.getName());
                    }else{
                        String ParentPath = name.substring(0, Index);
                        if( CreatePath(ParentPath) == false )
                            return false;
                        file = new File(outputDirectory + File.separator + entry.getName());
                    }
                    if( !file.exists() || OverWriteFlag == true){
                        file.createNewFile();
                        FileOutputStream out = new FileOutputStream(file);
                        int readLen = 0;
                        while((readLen = in.read(buffer)) != -1){
                            out.write(buffer, 0, readLen);
                        }
                        out.close();
                    }
                }
                entry = in.getNextEntry();
            }
            in.close();
            return true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        File destDir = new File("/data/data/"+getPackageName()+"/files");
        if(!destDir.exists())
            destDir.mkdirs();

        try {
            AssetManager localassetManager = getAssets();
            InputStream dataSource = localassetManager.open("aiohttp_module.zip");
            unzip(dataSource,"/data/data/"+getPackageName()+"/files",true);

            dataSource = localassetManager.open("certs.zip");
            unzip(dataSource,"/data/data/"+getPackageName()+"/files",true);

            /*---so--*/
            String nativeLibraryDir = this.getApplicationInfo().nativeLibraryDir;
            if (nativeLibraryDir.contains("x86")) {
            } else {
                copyFile(this, "_ssl.cpython-36m.so", "armeabi/");
                copyFile(this, "unicodedata.cpython-36m.so", "armeabi/");
                copyFile(this, "zlib.cpython-36m.so", "armeabi/");
                copyFile(this, "_posixsubprocess.cpython-36m.so", "armeabi/");
                copyFile(this, "select.cpython-36m.so", "armeabi/");
                copyFile(this, "math.cpython-36m.so", "armeabi/");
                copyFile(this, "array.cpython-36m.so", "armeabi/");
                copyFile(this, "_struct.cpython-36m.so", "armeabi/");
                copyFile(this, "_socket.cpython-36m.so", "armeabi/");
                copyFile(this, "_sha512.cpython-36m.so", "armeabi/");
                copyFile(this, "_random.cpython-36m.so", "armeabi/");
                copyFile(this, "_multiprocessing.cpython-36m.so", "armeabi/");
                copyFile(this, "binascii.cpython-36m.so", "armeabi/");
                copyFile(this, "_md5.cpython-36m.so", "armeabi/");
                copyFile(this, "_sha1.cpython-36m.so", "armeabi/");
                copyFile(this, "_sha3.cpython-36m.so", "armeabi/");
                copyFile(this, "_sha256.cpython-36m.so", "armeabi/");
                copyFile(this, "_blake2.cpython-36m.so", "armeabi/");
                copyFile(this, "python3.6.zip", null);

                copyFile(this, "test.py", null);
            }
        }
        catch (Exception ex){}
        try{
            //--load python36 core library first;
            System.load(this.getApplicationInfo().nativeLibraryDir+"/libpython3.6m.so");
        }
        catch(UnsatisfiedLinkError ex)
        {
            System.out.println(ex.toString());
        }

        /*----init starcore----*/
        StarCoreFactoryPath.StarCoreCoreLibraryPath = this.getApplicationInfo().nativeLibraryDir;
        StarCoreFactoryPath.StarCoreShareLibraryPath = this.getApplicationInfo().nativeLibraryDir;
        StarCoreFactoryPath.StarCoreOperationPath = "/data/data/"+getPackageName()+"/files";

        StarCoreFactory starcore= StarCoreFactory.GetFactory();
        StarServiceClass Service=starcore._InitSimple("test","123",0,0);
        StarSrvGroupClass SrvGroup = (StarSrvGroupClass)Service._Get("_ServiceGroup");
        Service._CheckPassword(false);

        /*----run python code----*/
        SrvGroup._InitRaw("python36",Service);
        StarObjectClass python = Service._ImportRawContext("python","",false,"");
        python._Call("import", "sys");

        StarObjectClass pythonSys = python._GetObject("sys");
        StarObjectClass pythonPath = (StarObjectClass)pythonSys._Get("path");
        pythonPath._Call("insert",0,"/data/data/"+getPackageName()+"/files/python3.6.zip");
        pythonPath._Call("insert",0,this.getApplicationInfo().nativeLibraryDir);
        pythonPath._Call("insert",0,"/data/data/"+getPackageName()+"/files/aiohttp_module");
        pythonPath._Call("insert",0,"/data/data/"+getPackageName()+"/files");

        python._Call("import", "aiohttp");

        StarObjectClass aiohttp = python._GetObject("aiohttp");
        SrvGroup._DoFile("python","/data/data/"+getPackageName()+"/files/test.py");
    }
}
