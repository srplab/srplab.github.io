// main
package main

import (
	"fmt"

	"github.com/srplab/starcore_for_go/stargo"
)

func main() {
	fmt.Println("Hello World!")
}

func init() {
	stargo.RegAttachRawContextCallBack_P(func(ContextName string) interface{} {
		if ContextName == "gofunc" {
			return func(v1 string, v2 float32) string {
				stargo.Println(v1)
				stargo.Println(v2)
				return "hello fro go"
			}
		}
		return nil
	})

	stargo.RegScriptTermCallBack_P(func() {
		stargo.Println("go script engine exit...")
	})

	stargo.RegScriptInitCallBack_P(func(SrvGroup *stargo.StarSrvGroup, Service *stargo.StarService) {
		stargo.Println("go script engine init...")

		/*--GoObject can be called from other script */
		s := Service.New("GoObject")
		s.RegScriptProc_P("PrintHello", func(CleGroup *stargo.StarSrvGroup, CleService *stargo.StarService, CleObject *stargo.StarObject, Paras []interface{}) interface{} {
			stargo.Println(Paras)
			return []interface{}{"return from go", 345.4}
		})
	})
}
