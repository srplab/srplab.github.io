export NDK_TOOLCHAIN=/home/lihm/Desktop/rust.study/android-18-toolchain
export CC=$NDK_TOOLCHAIN/bin/arm-linux-androideabi-gcc
#export GOROOT=~/dev/go
#export GOPATH=`pwd`
export GOOS=android
export GOARCH=arm
export GOARM=7
export CGO_ENABLED=1

GO="$GOROOT/bin/go"

$GO build -buildmode=c-shared -o libgosharelib.so

