// main
package main

import (
	"fmt"

	"github.com/srplab/starcore_for_go/stargo"
)

func MsgCallBack(ServiceGroupID uint32, uMsg uint32, wParam interface{}, lParam interface{}) (IsProcessed bool, Result interface{}) {
	if uMsg == stargo.MSG_VSDISPMSG || uMsg == stargo.MSG_VSDISPLUAMSG || uMsg == stargo.MSG_DISPMSG || uMsg == stargo.MSG_DISPLUAMSG {
		fmt.Println(wParam)
	} else {
		fmt.Println(ServiceGroupID, uMsg, wParam, lParam)
	}
	return false, 0
}

func main() {
	Service := stargo.InitSimple("test", "123", 0, 0)
	SrvGroup := Service.Get("_ServiceGroup").(*stargo.StarSrvGroup)
	Service.CheckPassword(false)

	stargo.RegMsgCallBack_P(MsgCallBack)

	SrvGroup.InitRaw("python36", Service)
	python := Service.ImportRawContext("python", "", false, "")

	Service.DoFile("python", "testpy.py", "")
	fmt.Println(python.Get("g1"))

	Multiply := Service.ImportRawContext("python", "Multiply", true, "")
	multiply := Multiply.New("", "", 33, 44)
	fmt.Printf("instance multiply = %d\n", multiply.Call("multiply", 11, 22))

	/*---test callback---*/
	Service.DoFile("python", " testcallback.py", "")

	CallBackObj := Service.New()
	python.Set("CallBackObj", CallBackObj)

	CallBackObj.RegScriptProc_P("PrintHello", func(CleGroup *stargo.StarSrvGroup, CleService *stargo.StarService, CleObject *stargo.StarObject, Paras []interface{}) interface{} {
		fmt.Println(Paras)
		return []interface{}{"return from go", 345.4}
	})

	retobj := python.Call("TestCallBack", "hello ", "world").(*stargo.StarObject)
	fmt.Println(retobj)
}
