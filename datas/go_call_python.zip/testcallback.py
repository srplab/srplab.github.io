def TestCallBack(a,b) :
    print(a,b)
    ParaPkg = CallBackObj.PrintHello("---------------",1234)
    print(ParaPkg[0])
    print(ParaPkg[1])
    return 666,777

