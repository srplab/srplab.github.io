//
//  AppDelegate.h
//  ios_call_ruby_kramdown
//
//  Created by srplab on 18/1/2.
//  Copyright © 2018年 srplab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

