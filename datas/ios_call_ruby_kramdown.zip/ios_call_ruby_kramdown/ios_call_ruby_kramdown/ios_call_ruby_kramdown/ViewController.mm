//
//  ViewController.m
//  ios_call_ruby_kramdown
//
//  Created by srplab on 18/1/2.
//  Copyright © 2018年 srplab. All rights reserved.
//

#import "ViewController.h"
#include "vsopenapi.h"

static class ClassOfSRPInterface *SRPInterface;

static VS_UWORD MsgCallBack( VS_ULONG ServiceGroupID, VS_ULONG uMsg, VS_UWORD wParam, VS_UWORD lParam, VS_BOOL *IsProcessed, VS_UWORD Para )
{
    switch( uMsg ){
        case MSG_VSDISPMSG :
        case MSG_VSDISPLUAMSG :
            printf("[core]%s\n",(VS_CHAR *)wParam);
            break;
        case MSG_DISPMSG :
        case MSG_DISPLUAMSG :
            printf("%s\n",(VS_CHAR *)wParam);
            break;
    }
    return 0;
}

extern "C" void ruby_init_ext(const char *name, void (*init)(void));
extern "C" void Init_socket();


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,   NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    const char* destDir = [documentsDirectory UTF8String];
    VS_BOOL Result = StarCore_Init((VS_CHAR *)destDir);
    
    VSCoreLib_InitRuby();
    
    VS_CORESIMPLECONTEXT Context;
    
    SRPInterface = VSCoreLib_InitSimple(&Context,"test","123",0,0,MsgCallBack,0,NULL);
    SRPInterface ->CheckPassword(VS_FALSE);
    
    //---set ruby search path
    NSString *respaths = [[NSBundle mainBundle] resourcePath];
    const VS_CHAR *res_cpath = [respaths UTF8String];
    
    class ClassOfBasicSRPInterface *BasicSRPInterface;
    
    BasicSRPInterface = SRPInterface ->GetBasicInterface();
    BasicSRPInterface ->InitRaw("ruby", SRPInterface);
    
    void *ruby = SRPInterface -> ImportRawContext("ruby", "", VS_FALSE, "");
    void *LOAD_PATH = (void *)SRPInterface -> ScriptGetObject(ruby,"LOAD_PATH", NULL);
    
    char pathbuf[512];
    sprintf(pathbuf,"%s/ruby/2.2.0",res_cpath);
    SRPInterface->ScriptCall(LOAD_PATH,NULL, "unshift", "(s)",pathbuf);
    
    sprintf(pathbuf,"%s/kramdown-1.16.2/lib",res_cpath);
    SRPInterface->ScriptCall(LOAD_PATH,NULL, "unshift", "(s)",pathbuf);
    
    //---call kramdown
    SRPInterface->ScriptCall(ruby,NULL, "require", "(s)","kramdown");
    void *KramdownDocument = (void *)SRPInterface->ScriptCall(ruby,NULL, "eval", "(s)o","Kramdown::Document");
    
    void *resobj = (void *)SRPInterface ->IMallocObjectL2(SRPInterface->GetIDEx(KramdownDocument),"s","# aaaaaa");
    char *html = (char *)SRPInterface->ScriptCall(resobj,NULL, "method_missing", "(s)s","to_html");
    
    
    BasicSRPInterface ->Release();
    SRPInterface -> Release();
    VSCoreLib_TermSimple(&Context);

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
