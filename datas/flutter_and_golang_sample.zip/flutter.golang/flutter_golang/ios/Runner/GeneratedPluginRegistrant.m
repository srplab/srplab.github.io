//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <starflut/StarflutPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [StarflutPlugin registerWithRegistrar:[registry registrarForPlugin:@"StarflutPlugin"]];
}

@end
