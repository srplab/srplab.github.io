rm -rf libstar_go.a

export PATH="/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/:/usr/local/bin:/usr/bin:/bin:$PATH"  
export SRCPATH="writting_golang_multithreading_extension_for_other_scripts"

arch=("i386" "x86_64" "arm64" "armv7");

for s in ${arch[@]}; do
  echo "build for $s"

  cd $SRCPATH

  export GOOS=darwin
  export CGO_ENABLED=1
  if [ "$s" == "armv7" ]; then
    export CFLAGS="-arch $s -miphoneos-version-min=6.0 -isysroot "$(xcrun -sdk iphoneos --show-sdk-path)
    export CC=/usr/local/go/misc/ios/clangwrap.sh
    export GOARCH=arm
    export GOARM=7
  elif [ "$s" == "i386" ]; then
    export CFLAGS="-arch $s -miphoneos-version-min=6.0 -isysroot "$(xcrun -sdk iphonesimulator --show-sdk-path)
    export CC="clang $CFLAGS"
    export GOARCH=386
  elif [ "$s" == "x86_64" ]; then
    export CFLAGS="-arch $s -miphoneos-version-min=6.0 -isysroot "$(xcrun -sdk iphonesimulator --show-sdk-path)
    export CC="clang $CFLAGS"
    export GOARCH=amd64
  elif [ "$s" == "arm64" ]; then
    export CFLAGS="-arch $s -miphoneos-version-min=6.0 -isysroot "$(xcrun -sdk iphoneos --show-sdk-path)
    export CC="clang $CFLAGS"
    export GOARCH=arm64
  fi

  go build -tags='ios' -buildmode=c-archive -o libstar_go.a
  
  cd ..
  mkdir $s
  cp $SRCPATH/libstar_go.a $s
  rm -rf $SRCPATH/libstar_go.a
 
done

lipo -create ./i386/libstar_go.a ./x86_64/libstar_go.a ./armv7/libstar_go.a ./arm64/libstar_go.a -o libstar_go.a

rm -rf ./i386
rm -rf ./x86_64
rm -rf ./armv7
rm -rf ./arm64

lipo -info libstar_go.a
