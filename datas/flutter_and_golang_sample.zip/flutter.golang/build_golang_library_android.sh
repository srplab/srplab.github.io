# compiled with android-ndk-r12b

GO="/usr/local/go/bin/go"

arch=("x86" "x86_64" "arm64" "arm");

for s in ${arch[@]}; do
  echo "build for $s"

  cd writting_golang_multithreading_extension_for_other_scripts

  export GOOS=android
  export CGO_ENABLED=1

  if [ "$s" == "arm" ]; then
    export NDK_TOOLCHAIN=/Users/srplab/Desktop/ndk_toolchain/android-toolchain.arm
    export CC=$NDK_TOOLCHAIN/bin/arm-linux-androideabi-gcc
    export GOARCH=arm
    export GOARM=7
  elif [ "$s" == "x86" ]; then
    export NDK_TOOLCHAIN=/Users/srplab/Desktop/ndk_toolchain/android-toolchain.x86
    export CC=$NDK_TOOLCHAIN/bin/i686-linux-android-gcc
    export GOARCH=386
  elif [ "$s" == "x86_64" ]; then
    export NDK_TOOLCHAIN=/Users/srplab/Desktop/ndk_toolchain/android-toolchain.x86_64
    export CC=$NDK_TOOLCHAIN/bin/x86_64-linux-android-gcc
    export GOARCH=amd64
  elif [ "$s" == "arm64" ]; then
    export NDK_TOOLCHAIN=/Users/srplab/Desktop/ndk_toolchain/android-toolchain.arm64
    export CC=$NDK_TOOLCHAIN/bin/aarch64-linux-android-gcc
    export GOARCH=arm64
  fi

  $GO build -buildmode=c-shared -o libstar_go.so
  
  cd ..
  if [ "$s" == "arm" ]; then
    cp writting_golang_multithreading_extension_for_other_scripts/libstar_go.so flutter_golang/android/app/src/main/jniLibs/armeabi-v7a
  elif [ "$s" == "x86" ]; then
    cp writting_golang_multithreading_extension_for_other_scripts/libstar_go.so flutter_golang/android/app/src/main/jniLibs/x86
  elif [ "$s" == "x86_64" ]; then
    cp writting_golang_multithreading_extension_for_other_scripts/libstar_go.so flutter_golang/android/app/src/main/jniLibs/x86_64
  elif [ "$s" == "arm64" ]; then
    cp writting_golang_multithreading_extension_for_other_scripts/libstar_go.so flutter_golang/android/app/src/main/jniLibs/arm64-v8a
  fi

  rm -rf writting_golang_multithreading_extension_for_other_scripts/libstar_go.so
 
done
