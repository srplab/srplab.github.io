#![allow(unused_variables)]
#![allow(non_snake_case)]
#![allow(unused_imports)]
#![allow(dead_code)]

extern crate starcore_for_rust;
use starcore_for_rust::*;
use std::any::Any;

fn MsgCallBack(ServiceGroupID: u32, uMsg: u32, wParam: &Any, lParam: &Any) -> (bool, Box<Any>)
{
	if uMsg == MSG_VSDISPMSG || uMsg == MSG_VSDISPLUAMSG || uMsg == MSG_DISPMSG || uMsg == MSG_DISPLUAMSG {
		println!("{}",starrust::ToString(wParam));
	} else {
	}
	return (false, Box::new(&0));
}

fn rustcallback(CleGroup:&STARSRVGROUP,CleService:&STARSERVICE,CleObject:&starrust::STAROBJECT,Paras: &[starrust::STARRESULT]) -> starrust::STARRESULT {
    starrust::println(format!("{}",Paras[0].ToString()));
    starrust::println(format!("{}",Paras[1].ToInt()));
	return Some(Box::new(CleGroup.NewParaPkg(&[&"return from go", &345.4])));
}

fn main() {
	let Service = starrust::InitSimple(&"test",&"123", 0, 0,&[]);
	let SrvGroup = Service.Get(&"_ServiceGroup").ToSrvGroup();
    Service.CheckPassword(false);

    starrust::RegMsgCallBack_P(MsgCallBack);
        
    let initResult = SrvGroup.InitRaw(&"python36", &Service);
    let python = Service.ImportRawContext(&"python", &"", false, &"");

	Service.DoFile(&"python", &"testpy.py", &"");
    println!("{}",python.GetInt(&"g1"));

    let Multiply = Service.ImportRawContext(&"python", &"Multiply", true, &"");
    let multiply = Multiply.New(&[&"",&"",&33,&44]);
    println!("instance multiply = {:?}", multiply.CallInt(&"multiply", &[&11, &22]));

    Service.DoFile(&"python", &"testcallback.py", &"");
    let CallBackObj = Service.New(&[]);
    python.Set(&"CallBackObj", &CallBackObj);
    CallBackObj.RegScriptProc_P(&"PrintHello",rustcallback);
    let retobj = python.Call(&"TestCallBack", &[&"hello ", &"world"]);
	println!("{:?}",retobj.Type());
    println!("{:?}",retobj.ToObject().GetInt(&0));
    println!("{:?}",retobj.ToObject().GetInt(&1));
}