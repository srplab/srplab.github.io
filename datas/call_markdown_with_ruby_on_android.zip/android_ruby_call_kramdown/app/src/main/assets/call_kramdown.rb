begin
  require 'enc/encdb'
  require 'kramdown'
  puts Kramdown::Document.new("# ssssss").to_html
rescue Exception => e
  puts e.message
  puts e.backtrace.inspect
ensure
  puts "Ensuring execution"
end